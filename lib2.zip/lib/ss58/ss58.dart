/// Library for SS58 address encoding and decoding.
library ss58;

/// Export statement for SS58 address encoding-decoding functionality.
export 'ss58_base.dart';
