import 'package:blockchain_utils/binary/binary_operation.dart';
import 'package:blockchain_utils/exception/exception.dart';
import 'package:blockchain_utils/numbers/bigint_utils.dart';
import 'package:blockchain_utils/string/string.dart';

import 'package:blockchain_utils/hex/hex.dart' as hex;

/// A utility class for working with binary data represented as lists of integers (bytes).
class BytesUtils {
  /// Performs a bitwise XOR operation on two lists of bytes.
  ///
  /// Takes two lists of bytes and returns a new list where each byte is the result
  /// of the XOR operation between the corresponding bytes in the input lists.
  static List<int> xor(List<int> dataBytes1, List<int> dataBytes2) {
    return List<int>.from(List<int>.generate(
      dataBytes1.length,
      (index) => dataBytes1[index] ^ dataBytes2[index],
    ));
  }

  /// Converts a list of bytes to a binary string representation.
  ///
  /// Converts the input list of bytes to a binary string, optionally adding leading
  /// zeros to ensure a specific bit length.
  static String toBinary(List<int> dataBytes, {int zeroPadBitLen = 0}) {
    return BigintUtils.toBinary(
        BigintUtils.fromBytes(dataBytes), zeroPadBitLen);
  }

  /// Converts a binary string to a list of bytes.
  ///
  /// Parses a binary string and converts it back to a list of bytes. An optional
  /// parameter allows padding the result with zeros to achieve a specific byte length.
  static List<int> fromBinary(String data, {int zeroPadByteLen = 0}) {
    BigInt intValue = BigInt.parse(data, radix: 2);
    String hexValue = intValue.toRadixString(16).padLeft(zeroPadByteLen, '0');
    return fromHexString(hexValue);
  }

  /// Converts a List of integers representing bytes, [dataBytes], into a
  /// hexadecimal string.
  ///
  /// The method uses the `hex` library to encode the byte list into a
  /// hexadecimal string. It allows customization of the string's case
  /// (lowercase or uppercase) using the [lowerCase] parameter, and an optional
  /// [prefix] string can be appended to the resulting hexadecimal string.
  ///
  /// Parameters:
  /// - [dataBytes]: A List of integers representing bytes to be converted.
  /// - [lowerCase]: Whether the resulting hexadecimal string should be in
  ///   lowercase (default is true).
  /// - [prefix]: An optional string to append as a prefix to the hexadecimal string.
  ///
  /// Returns:
  /// - A hexadecimal string representation of [dataBytes].
  ///
  static String toHexString(List<int> dataBytes,
      {bool lowerCase = true, String? prefix}) {
    final String toHex = hex.hex.encode(dataBytes, lowerCase);
    return "${prefix ?? ''}$toHex";
  }

  /// Tries to convert a list of integers representing bytes, [dataBytes], into a
  /// hexadecimal string.
  ///
  /// If [dataBytes] is null, returns null. Otherwise, attempts to convert the
  /// byte list into a hexadecimal string using the [toHexString] function.
  /// If successful, returns the resulting hexadecimal string; otherwise, returns null.
  ///
  /// Parameters:
  /// - [dataBytes]: A List of integers representing bytes to be converted.
  /// - [lowerCase]: Whether the resulting hexadecimal string should be in
  ///   lowercase (default is true).
  /// - [prefix]: An optional string to append as a prefix to the hexadecimal string.
  ///
  /// Returns:
  /// - A hexadecimal string representation of [dataBytes], or null if conversion fails.
  ///
  static String? tryToHexString(List<int>? dataBytes,
      {bool lowerCase = true, String? prefix}) {
    if (dataBytes == null) return null;
    try {
      return toHexString(dataBytes, lowerCase: lowerCase, prefix: prefix);
    } catch (e) {
      return null;
    }
  }

  /// Converts a hexadecimal string [data] into a List of integers representing bytes.
  ///
  /// The method removes the '0x' prefix, strips leading zeros, and decodes the
  /// resulting hexadecimal string into bytes. Optionally, it pads zero if the
  /// string length is odd and the [paddingZero] parameter is set to true.
  ///
  /// Parameters:
  /// - [data]: The hexadecimal string to be converted.
  /// - [paddingZero]: Whether to pad a zero to the string if its length is odd
  ///   (default is false).
  ///
  /// Returns:
  /// - A List of integers representing bytes converted from the hexadecimal string.
  ///
  /// Throws:
  /// - [ArgumentException] if the input is not a valid hexadecimal string.
  ///
  static List<int> fromHexString(String data, {bool paddingZero = false}) {
    try {
      String hexString = StringUtils.strip0x(data);
      if (hexString.isEmpty) return [];
      if (paddingZero && hexString.length.isOdd) {
        hexString = "0$hexString";
      }
      return hex.hex.decode(hexString);
    } catch (e) {
      throw ArgumentException("invalid hex bytes");
    }
  }

  /// Tries to convert a hexadecimal string [data] into a List of integers.
  ///
  /// If [data] is null, returns null. Otherwise, attempts to parse the
  /// hexadecimal string using the [fromHexString] function. If successful,
  /// returns the resulting List of integers; otherwise, returns null.
  static List<int>? tryFromHexString(String? data) {
    if (data == null) return null;
    try {
      return fromHexString(data);
    } catch (e) {
      return null;
    }
  }

  /// Ensures that each byte is properly represented as an 8-bit integer.
  ///
  /// Performs a bitwise AND operation with a mask (`mask8`) to ensure that each byte in
  /// the input list is represented as an 8-bit integer.
  static List<int> toBytes(List<int> bytes, {bool unmodifiable = false}) {
    final toBytes = bytes.map((e) => e & mask8).toList();
    if (unmodifiable) {
      return List<int>.unmodifiable(toBytes);
    }
    return toBytes;
  }

  static List<int>? tryToBytes(List<int>? bytes, {bool unmodifiable = false}) {
    if (bytes == null) return null;
    return toBytes(bytes, unmodifiable: unmodifiable);
  }

  /// Validates a list of integers representing bytes.
  ///
  /// Ensures that each integer in the provided [bytes] list falls within the
  /// valid byte range (0 to 255). If any byte is outside this range,
  /// throws an [ArgumentException] with a descriptive error message.
  ///
  /// Parameters:
  /// - [bytes]: A List of integers representing bytes to be validated.
  ///
  /// Throws:
  /// - [ArgumentException] if any byte is outside the valid range.
  ///
  static void validateBytes(List<int> bytes) {
    for (final int i in bytes) {
      if (i < 0 || i > mask8) {
        throw ArgumentException("invalid bytes $i");
      }
    }
  }

  /// Compare two Uint8Lists lexicographically.
  static int compareBytes(List<int> a, List<int> b) {
    final length = a.length < b.length ? a.length : b.length;

    for (var i = 0; i < length; i++) {
      if (a[i] < b[i]) {
        return -1;
      } else if (a[i] > b[i]) {
        return 1;
      }
    }

    if (a.length < b.length) {
      return -1;
    } else if (a.length > b.length) {
      return 1;
    }

    return 0;
  }
}
